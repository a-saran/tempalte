var user;
url="http://starlord.hackerearth.com/movieslisting";

function getDetails(){
    var http = new XMLHttpRequest();
    http.onreadystatechange = function(){
        if(http.readyState == 4 && http.status ==200){
            user = JSON.parse(http.responseText);
            //console.log(user);
            init();
            uniLang();
            uniCountry();
            uniYear();
        }
    }
    http.open('GET',url,true);
    http.send();
}
getDetails();


function lightTheme(){
    $('.navbar').removeClass('bg-dark');
    $('.navbar').removeClass('navbar-dark');
    $('.navbar').addClass('bg-light');
    $('.navbar').addClass('navbar-light');
    $('.table').addClass('table-striped');
    $('.table').removeClass('table-striped table-dark');
    //$('.jumbotron').removeClass('bg-dark-jumbotron');
    //$('.jumbotron').addClass('bg-light-jumbotron');
    $('.totbody').removeClass('bgcolor');
    $('.sbtn').removeClass('btn-primary');
    $('.sbtn').addClass('btn-grey');
    $('.footer1').removeClass('ftbg');
    $('.btn-outline-dark').addClass('btn-outline-primary');
    $('.btn-outline-dark').removeClass('btn-outline-dark');
}
function darkTheme(){
    $('.navbar').removeClass('navbar-light');
    $('.navbar').removeClass('bg-light');
    $('.navbar').addClass('bg-dark');
    $('.navbar').addClass('navbar-dark');
    $('.table').addClass('table-striped table-dark table-bordered');
    //$('.jumbotron').removeClass('bg-light-jumbotron');
    //$('.jumbotron').addClass('bg-dark-jumbotron');
    $('.totbody').addClass('bgcolor');
    $('.sbtn').removeClass('btn-grey');
    $('.sbtn').addClass('btn-outline-primary');
    $('.footer1').addClass('ftbg');
    $('.btn-outline-primary').addClass('btn-outline-dark');
    $('.btn-outline-primary').removeClass('btn-outline-primary');
}

function Data(s ,e){
    $('#movie-data').empty();
    if(user.length > 0) {
        for(i=s ;i<e; i++){   
            document.getElementById('movie-data').innerHTML +=`
            <tr>
                <td>${ user[i].language}</td>
                <td>${ user[i].movie_title}</td>
                <td>${ user[i].country }</td>
                <td>${ user[i].genres}</td>
                <td>${ user[i].budget}</td>
                <td>${ user[i].title_year}</td>
            </tr>
            `;
        }
    }
    else{
        document.getElementById('movie-data').innerHTML +=`<h1>Result Not Found</h1>
        <h3>You have Filtered all [OR] click list_all_movies to list all the movies</h3>`;
    }
}

//list  all
function listAll(){
    getDetails();
}

//Filter Language
var uniqLang =[];
function uniLang(){
    for(var i=0;i< user.length; i++ ){
        uniqLang.push(user[i].language);
    }
    uniqLang = uniqLang.filter(function(item, pos){
        return uniqLang.indexOf(item)== pos; 
    });
    uniqLang = uniqLang.filter(x => x);
    var list1 = '';
    for(var i=0; i<uniqLang.length; i++)
    {
        list1 += '<li data-item="'+ uniqLang[i] + '" class="dropdown-item _clickedLangFilter" href="#" onclick="" data-dismiss="modal">'+ uniqLang[i] + '</li>';
        
    }
    $('#languageFilter1').html(list1);
}
$(document).on('click','._clickedLangFilter',function() {
    var newvalue1 = $(this).data("item");
    var langFilter=[];
    for( var i=0 ; i<user.length ; i++){
        if(user[i].language == newvalue1){
            langFilter.push(user[i]);
        }
    }
    user=langFilter;
    init();
});

//country Filter
var uniqCty =[];
function uniCountry(){
    for(var i=0;i< user.length; i++ ){
        uniqCty.push(user[i].country);
    }
    uniqCty = uniqCty.filter(function(item, pos){
        return uniqCty.indexOf(item)== pos; 
    });
    uniqCty = uniqCty.filter(x => x);
    var list2 = '';
    for(var i=0; i<uniqCty.length; i++)
    {
        list2 += '<li data-item="'+ uniqCty[i] + '" class="dropdown-item _clickedCountryFilter" href="#" onclick="" data-dismiss="modal">'+ uniqCty[i] + '</li>';   
    }
    $('#countryFilter').html(list2);
}
$(document).on('click','._clickedCountryFilter',function() {
    var newvalue2 = $(this).data("item");
    var countryFilter=[];
    for( var i=0 ; i<user.length ; i++){
        if(user[i].country == newvalue2){
            countryFilter.push(user[i]);
        }
    }
    user=countryFilter;
    init();
});

//year filter
var uniqYear =[];
function uniYear(){
    for(var i=0;i< user.length; i++ ){
        uniqYear.push(user[i].title_year);
    }
    uniqYear = uniqYear.filter(function(item, pos){
        return uniqYear.indexOf(item)== pos; 
    });
    uniqYear = uniqYear.filter(x => x);
    var list3 = '';
    for(var i=0; i<uniqYear.length; i++)
    {
        list3 += '<li data-item="'+ uniqYear[i] + '" class="dropdown-item _clickedYearFilter" href="#" onclick="" data-dismiss="modal">'+ uniqYear[i] + '</li>';
        
    }
    $('#yearFilter').html(list3);
}
$(document).on('click','._clickedYearFilter',function() {
    var newvalue3 = $(this).data("item");
    var yearFilter=[];
    for( var i=0 ; i<user.length ; i++){
        if(user[i].title_year == newvalue3){
            yearFilter.push(user[i]);
        }
    }
    user=yearFilter;
   // Data(0,user.length);
   init();
});


//budget Filter
function budFilter1(){
    var bugs=[];
    for(var i=0 ; i<user.length ; i++){
        if((user[i].budget >= 0) &&(user[i].budget <= 10000000)){
            bugs.push(user[i]);
        }
    }
    user = bugs;
    init();
}
function budFilter2(){
    var bugs=[];
    for(var i=0 ; i<user.length ; i++){
        if((user[i].budget > 10000000) &&(user[i].budget <= 50000000)){
            bugs.push(user[i]);
        }
    }
    user = bugs;
    init();
}
function budFilter3(){
    var bugs=[];
    for(var i=0 ; i<user.length ; i++){
        if((user[i].budget > 50000000) &&(user[i].budget <= 100000000)){
            bugs.push(user[i]);
        }
    }
    user = bugs;
    init();
}
function budFilter4(){
    var bugs=[];
    for(var i=0 ; i<user.length ; i++){
        if((user[i].budget > 100000000) &&(user[i].budget <= 200000000)){
            bugs.push(user[i]);
        }
    }
    user = bugs;
    init();
}
function budFilter5(){
    var bugs=[];
    for(var i=0 ; i<user.length ; i++){
        if((user[i].budget > 200000000) &&(user[i].budget <= 250000000)){
            bugs.push(user[i]);
        }
    }
    user = bugs;
    init();
}
function budFilter6(){
    var bugs=[];
    for(var i=0 ; i<user.length ; i++){
        if(user[i].budget > 250000000){
            bugs.push(user[i]);
        }
    }
    user = bugs;
    init();
}



//sorting//
function ascendingByYear(){
    user.sort(function(a, b){
        return b.title_year - a.title_year;
    });
    init();
}
function descendingByYear(){
    user.sort(function(a, b){
        return a.title_year - b.title_year;
    });
    init();
}
function languageAscen(){
    user.sort(function(a, b){
        return ((a.language == b.language) ? 0 : ((a.language > b.language) ? 1 : -1 ));
    });
    init();
}
function languageDescen(){
    user.sort(function(a, b){
        return ((b.language == a.language) ? 0 : ((b.language > a.language) ? 1 : -1 ));
    });
    init();
}
function countryAscen(){
    user.sort(function(a, b){
        return ((b.country == a.country) ? 0 : ((b.country > a.country) ? 1 : -1 ));
    });
    init();
}
function countryDescen(){
    user.sort(function(a, b){
        return ((a.country == b.country) ? 0 : ((a.country > b.country) ? 1 : -1 ));
    });
    init();
}

function budgetAscen(){
    user.sort(function(a, b){
        return b.budget - a.budget;
    });
    init();
}
function budgetDescen(){
    user.sort(function(a, b){
        return a.budget - b.budget;
    });
    init();
}

//sort modal
$('#myModal').on('shown.bs.modal', function () {
    $('#myInput').trigger('focus')
});



var sta = 0;
var limit = 0; 
var max_size;
var elements_per_page = 10;

function init(){
    limit = elements_per_page;
    Data(sta,limit);
    max_size=user.length;
    localStorage.setItem('max',max_size); 
}

$('#nextValue').click(function(){
    var next = limit;
    max_size = parseInt(localStorage.getItem('max'));
    //console.log(max_size);
    if(max_size>=next) {
        limit = limit+elements_per_page;
        $('#movie-data').empty();
        Data(next,limit);
    }
});

$('#PreeValue').click(function(){
    var pre = limit-(2*elements_per_page);
    if(pre>=0) {
        limit = limit-elements_per_page;
        $('#movie-data').empty();
        Data(pre,limit); 
    }
});




